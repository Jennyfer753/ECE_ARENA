#include "gestion_jeu.h"

int main() {
    lancer_jeu();
    return 0;
}
END_OF_MAIN();
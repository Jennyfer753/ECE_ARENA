//
// Created by Admin on 17/05/2025.
//

#include "choix_partie.h"
#include <allegro.h>
#include "menu.h"

BITMAP* charger_img_parties() {
    BITMAP* img = load_bitmap("img_parties.bmp", NULL);
    if (!img) {
        allegro_message("Erreur chargement fond_parties.bmp");
        exit(1);
    }
    return img;
}

void config_partie(BITMAP* buffer, BITMAP* img_parties) {
    if (img_parties) {
        draw_sprite(buffer, img_parties, 0, 0);
    } else {
        clear_bitmap(buffer);
    }
    rectfill(buffer, 220, 200, 380, 250, makecol(72, 108, 75));
    textout_centre_ex(buffer, font, "Partie à 2", 300, 215, makecol(255, 255, 255), -1);
    if (mouse_x >= 220 && mouse_x <= 380 && mouse_y >= 200 && mouse_y <= 250 ) {
        rect(buffer, 210, 190, 390, 260, makecol(80, 240, 158));
        textout_ex(buffer, font, ">", 230, 215, makecol(255, 255, 255), -1);
    }

    rectfill(buffer, 420, 200, 580, 250, makecol(72, 108, 75));
    textout_centre_ex(buffer, font, "Partie à 3", 500, 215, makecol(255, 255, 255), -1);
    if(mouse_x >= 420 && mouse_x <= 580 && mouse_y >= 200 && mouse_y <= 250) {
        rect(buffer, 410, 190, 590, 260, makecol(80, 240, 158));
        textout_ex(buffer, font, ">", 430, 215, makecol(255, 255, 255), -1);
    }

    rectfill(buffer, 320, 280, 480, 330, makecol(72, 108, 75));
    textout_centre_ex(buffer, font, "Partie à 4", 400, 295, makecol(255, 255, 255), -1);
    if(mouse_x >= 320 && mouse_x <= 480 && mouse_y >= 280 && mouse_y <= 330) {
        rect(buffer, 310, 270, 490, 340, makecol(80, 240, 158));
        textout_ex(buffer, font, ">", 330, 295, makecol(255, 255, 255), -1);
    }
    rectfill(buffer, 50, 550, 150, 580, makecol(72, 108, 75));
    textout_centre_ex(buffer, font, "RETOUR", 100, 560, makecol(255, 255, 255), -1);
    if(mouse_x >= 50 && mouse_x <= 150 && mouse_y >= 550 && mouse_y <= 580) {
        rect(buffer, 40, 540, 160, 590, makecol(80, 240, 158));
        textout_ex(buffer, font, ">", 60, 560, makecol(255, 255, 255), -1);
    }
}


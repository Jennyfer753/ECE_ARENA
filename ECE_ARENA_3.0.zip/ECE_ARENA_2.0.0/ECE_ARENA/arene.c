//
// Created by Admin on 20/04/2025.
//
#include <stdio.h>
#include <allegro.h>
#include "arene.h"

void arene(BITMAP* buffer) {
    int arene[15][15] = {0};
    int taille_case = 40;
    int nb_lignes = 13;
    int nb_colonnes = 15;

    int decalage_x = 20;
    int decalage_y = (600 - nb_lignes * taille_case) / 2;

    for (int ligne = 0; ligne < nb_lignes; ligne++) {
        for (int colonne = 0; colonne < nb_colonnes; colonne++) {
            int x = decalage_x + colonne * taille_case;
            int y = decalage_y + ligne * taille_case;

            int couleur;
            if (arene[ligne][colonne] == 0) {
                couleur = makecol(0, 0, 0);
            } else {
                couleur = makecol(100, 100, 100);
            }

            rectfill(buffer, x, y, x + taille_case - 1, y + taille_case - 1, couleur);
            rect(buffer, x, y, x + taille_case - 1, y + taille_case - 1, makecol(255, 255, 255));
        }
    }
}
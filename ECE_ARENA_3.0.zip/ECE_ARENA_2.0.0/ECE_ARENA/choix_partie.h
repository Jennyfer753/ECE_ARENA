//
// Created by Admin on 17/05/2025.
//

#ifndef CHOIX_PARTIE_H
#define CHOIX_PARTIE_H
#include <allegro.h>
BITMAP* charger_img_parties();
void config_partie(BITMAP* buffer, BITMAP* img_parties);
#endif //CHOIX_PARTIE_H

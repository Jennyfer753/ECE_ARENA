//
// Created by Admin on 16/05/2025.
//

#ifndef CLASSES_H
#define CLASSES_H
#include <attaque_sort.h>
void charger_classes(ClassePersonnage *classes);
#endif //CLASSES_H

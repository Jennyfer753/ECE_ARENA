//
// Created by Admin on 20/04/2025.
//

#ifndef ATTAQUE_SORT_H
#define ATTAQUE_SORT_H
#include <allegro.h>

typedef struct {
    int pv_retire_min;
    int pv_retire_max;
    int pa_requis;
    char nom[30];
    int portee_min;
    int portee_max;
    int chance_echec;
    int zone_effet; // 0 = cible unique, 1 = cases adjacentes, etc.
    BITMAP* animation[10]; // Tableau pour les frames d'animation
    int nb_frames;
    int frame_delay; // Délai entre chaque frame
} Sort;

typedef struct {
    Sort sorts[4]; // Chaque personnage a 4 sorts
    char nom_classe[50];
    BITMAP* sprite;
} ClassePersonnage;


#endif //ATTAQUE_SORT_H

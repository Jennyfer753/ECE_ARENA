//
// Created by Admin on 20/04/2025.
//
#ifndef JOUEURS_H
#define JOUEURS_H

typedef struct {
    int ligne;
    int colonne;
    int couleur;
    int pv ;
    int pm;
    int pa;
    char classe[51];
    char nom[51];
} init_joueurs;

#endif //JOUEURS_H

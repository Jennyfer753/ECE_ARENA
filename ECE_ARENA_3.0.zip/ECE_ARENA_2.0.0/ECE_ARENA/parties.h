//
// Created by Admin on 05/05/2025.
//

#ifndef PARTIES_H
#define PARTIES_H

void init_1v1(BITMAP* buffer);
void init_1v1v1(BITMAP* buffer);
void init_1v1v1v1(BITMAP* buffer);
#endif //PARTIES_H

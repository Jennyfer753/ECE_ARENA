//
// Created by Admin on 19/04/2025.
//

#ifndef MENU_H
#define MENU_H

void ecran_menu(BITMAP* buffer);
void config_partie(BITMAP* buffer);
#endif //MENU_H

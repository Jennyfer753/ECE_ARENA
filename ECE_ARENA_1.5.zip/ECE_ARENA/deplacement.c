//
// Created by Admin on 20/04/2025.
//
#include <allegro.h>
#include "deplacement.h"
#include "joueurs.h"
#include "arene.h"
/**
 * ajouter ici la gestion du deplacements des joueurs et des obstacles
 */
void deplacement(BITMAP* buffer, init_joueurs* j, int nb_joueurs) {
    clear_bitmap(buffer);
    int taille_case = 50;
    static int joueur_choisi = -1;
    int case_occupee ;
    int largeur = (SCREEN_W - 110) / taille_case;
    int hauteur = SCREEN_H / taille_case;
    static int position_prec = 0;
    int position_actuel = mouse_b & 1;
    int ligne_clic;
    int colonne_clic;

    if (position_actuel && !position_prec) {
        ligne_clic = mouse_y / taille_case;
        colonne_clic = (mouse_x - 110) / taille_case;

        if (ligne_clic >= 0 && ligne_clic < hauteur && colonne_clic >= 0 && colonne_clic < largeur) {
            if (joueur_choisi == -1) {
                for (int i = 0; i < nb_joueurs; i++) {
                    if (j[i].ligne == ligne_clic && j[i].colonne == colonne_clic) {
                        joueur_choisi = i;
                        break;
                    }
                }
            }
            else {
                case_occupee = 0;
                for (int i = 0; i < nb_joueurs; i++) {
                    if (i != joueur_choisi &&
                        j[i].ligne == ligne_clic &&
                        j[i].colonne == colonne_clic) {
                        case_occupee = 1;
                        break;
                    }
                }
                if (!case_occupee) {
                    j[joueur_choisi].ligne = ligne_clic;
                    j[joueur_choisi].colonne = colonne_clic;
                }
                joueur_choisi = -1;
            }
        }
        else {
            joueur_choisi = -1;
        }
    }
    arene(buffer);

    for (int i = 0; i < nb_joueurs; i++) {
        int x = 110 + j[i].colonne * taille_case + taille_case / 2;
        int y = j[i].ligne * taille_case + taille_case / 2;
        circlefill(buffer, x, y, 20, j[i].couleur);
        if (i == joueur_choisi) {
            circle(buffer, x, y, 25, makecol(255,0 , 255));
        }
    }
    position_prec = position_actuel;
}

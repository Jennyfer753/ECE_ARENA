//
// Created by Admin on 20/04/2025.
//

#ifndef DEPLACEMENT_H
#define DEPLACEMENT_H
#include "joueurs.h"
void deplacement(BITMAP* buffer, init_joueurs* j, int nb_joueurs);
#endif //DEPLACEMENT_H

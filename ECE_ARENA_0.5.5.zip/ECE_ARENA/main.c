#include <stdio.h>
#include <allegro.h>
#include "menu.h"

BITMAP* buffer;

void arene(BITMAP* buffer) {
    int taille_case = 100;
    int largeur = 10;
    int longueur = 10;
    for (int ligne = 0; ligne < longueur; ligne++) {
        for (int colonne = 0; colonne < largeur; colonne++) {
            int x = colonne * taille_case;
            int y = ligne * taille_case;
            rectfill(buffer, x, y, x + taille_case, y + taille_case,makecol(0,0,0));
            rect(buffer, x, y, x + taille_case, y + taille_case, makecol(255, 255, 255));
        }
    }
}

void initialisation_allegro(){
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0)!=0){
        allegro_message("problème gfx mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    buffer = create_bitmap(800, 600);
    if (!buffer) {
        allegro_message("Erreur allocation buffer");
        exit(EXIT_FAILURE);
    }
    show_mouse(screen);
}

int main() {
    int x1=300;
    int x2=500;
    int y1=250;
    int y2=350;

    int etat_jeu=0;

    initialisation_allegro();

    while (!key[KEY_ESC]) {
        clear_bitmap(buffer);
        if (etat_jeu == 0) {
            ecran_menu(buffer);
            if ((mouse_b & 1) && (mouse_x >= x1) && (mouse_x <= x2) && (mouse_y >= y1) && (mouse_y <= y2)) {
                etat_jeu = 1;
            }
        }
        else {
            arene(buffer);
        }
        blit(buffer, screen, 0, 0, 0, 0, 800, 600);
    }
    destroy_bitmap(buffer);
    return 0;
}
END_OF_MAIN();

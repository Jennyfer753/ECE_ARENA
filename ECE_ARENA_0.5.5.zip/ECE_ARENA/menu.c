//
// Created by Admin on 19/04/2025.
//
#include <stdio.h>
#include <allegro.h>
#include "menu.h"

void ecran_menu(BITMAP* buffer) {
    int x1=300;
    int x2=500;
    int y1=250;
    int y2=350;
    clear_bitmap(buffer);
    rectfill(buffer,x1,y1,x2,y2,makecol(255, 0, 0));
}
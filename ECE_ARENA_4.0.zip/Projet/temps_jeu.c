//
// Created by alois on 18/05/2025.
//

#include <allegro.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "allegro_init.h"
#include <allegro.h>
#include <time.h>

// Variables internes au module
static clock_t start_time = 0;
static int secondes = 0;

// Fonction d'affichage et de logique du minuteur
int temps(BITMAP* buffer) {
    char temps_str[10];

    if (start_time == 0)
        start_time = clock();  // Initialisation au premier appel

    clock_t elapsed = (clock() - start_time) / CLOCKS_PER_SEC;
    if (elapsed > secondes)
        secondes = elapsed;

    // Dessin du rectangle rouge et du compteur
    rectfill(buffer, 740, 25, 775, 40, makecol(255, 0, 0));
    sprintf(temps_str, "%02d", secondes);


    // Retourne 1 si 15 secondes écoulées
    if (secondes >= 15) {
        secondes = 0;
        start_time = clock();  // Redémarrer le compteur
        return 1;
    }

    return 0;
}

// Fonction à appeler pour réinitialiser le chrono manuellement
void reinit_temps() {
    start_time = 0;
    secondes = 0;
}

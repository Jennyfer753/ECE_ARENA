//
// Created by alois on 18/05/2025.
//

#include "tours.h"
#include "deplacement.h"
#include "file.h"
#include <stdlib.h>

#define MAX_JOUEURS 4  // Tu peux augmenter si nécessaire

// Fonction de mélange des indices
void melanger_indices(int* indices, int n) {
    for (int i = n - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indices[i];
        indices[i] = indices[j];
        indices[j] = temp;
    }
}

// Fonction pour mélanger les joueurs et les enfiler dans la file
void initialiser_file_tours(t_file* file, init_joueurs* joueurs, int nb_joueurs) {
    if (nb_joueurs < 2 || nb_joueurs > MAX_JOUEURS) {
        // Gérer l'erreur ou ignorer selon ton besoin
        return;
    }

    int indices[MAX_JOUEURS];  // Tableau statique taille max
    for (int i = 0; i < nb_joueurs; i++) {
        indices[i] = i;
    }

    melanger_indices(indices, nb_joueurs);
    init_file(file);

    for (int i = 0; i < nb_joueurs; i++) {
        enfiler(file, &joueurs[indices[i]]);
    }
}



//
// Created by alois on 18/05/2025.
//

#ifndef TEMPS_JEU_H
#define TEMPS_JEU_H
#include "parties.h"
void my_delay(int i);
int temps(BITMAP* buffer);
void reinit_temps();

#endif //TEMPS_JEU_H

//
// Created by Admin on 08/05/2025.
//

#ifndef GESTION_SONS_H
#define GESTION_SONS_H

void init_son(int* etat_son);
void bouton_son(BITMAP* buffer, int* etat_son);
void clic(int x, int y, int* etat_son);

#endif //GESTION_SONS_H

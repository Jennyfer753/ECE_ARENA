#include <allegro.h>

void dessiner_arene(BITMAP* buffer) {
    int taille_case = 100;
    int largeur = 10;
    int longueur = 10;
    for (int ligne = 0; ligne < longueur; ligne++) {
        for (int colonne = 0; colonne < largeur; colonne++) {
            int x = colonne * taille_case;
            int y = ligne * taille_case;
            rectfill(buffer, x, y, x + taille_case, y + taille_case,makecol(0,0,0));
            rect(buffer, x, y, x + taille_case, y + taille_case, makecol(255, 255, 255));
        }
    }
}
void initialisation_allegro(){
    allegro_init();
    install_keyboard();
    install_mouse();
    set_color_depth(desktop_color_depth());
    if (set_gfx_mode(GFX_AUTODETECT_WINDOWED,800,600,0,0)!=0){
        allegro_message("prb gfx mode");
        allegro_exit();
        exit(EXIT_FAILURE);
    }
    BITMAP* buffer = create_bitmap(800, 600);
    while (!key[KEY_ESC]) {
        dessiner_arene(buffer);
        blit(buffer, screen, 0, 0, 0, 0, 800, 600);
    }

    destroy_bitmap(buffer);


}
int main() {
    initialisation_allegro();
    return 0;
}
END_OF_MAIN();

//
// Created by alois on 18/05/2025.
//

#ifndef ARENE_H
#define ARENE_H

void arene(BITMAP* buffer);

#endif //ARENE_H

//
// Created by alois on 18/05/2025.
//

#ifndef CHOIX_CLASSE_H
#define CHOIX_CLASSE_H
#include "allegro.h"
#include "joueurs.h"
void choix_perso(BITMAP* buffer, init_joueurs* j,  int id_joueur);

#endif //CHOIX_CLASSE_H

//
// Created by alois on 18/05/2025.
//

#ifndef GESTION_STATES_H
#define GESTION_STATES_H
#include "joueurs.h"

void state(BITMAP* buffer, init_joueurs* j, int nb_joueurs, int taille_case);

#endif //GESTION_STATES_H

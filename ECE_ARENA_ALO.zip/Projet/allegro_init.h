//
// Created by alois on 18/05/2025.
//

#ifndef ALLEGRO_INIT_H
#define ALLEGRO_INIT_H
void initialisation_allegro(BITMAP** buffer);

#endif //ALLEGRO_INIT_H
